.. autolabor_simulation documentation master file, created by
   sphinx-quickstart on Mon May 28 23:42:15 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

======================================
Autolabor_simulation Documentation
======================================


.. toctree::
   :maxdepth: 2

   getting_start
   tf_coordinate_introduction


autolabor_simulation是一款基于autolabor机器人的轻量级模拟器，它提供了一套
开箱即用的ROS配置和友好的交互方式。能够模拟机器人底盘，单线激光雷达，自定义
障碍。并且可以自由配置各个传感器的干扰数据。





Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

