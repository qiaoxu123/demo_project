
===================================
TF Coordinate Introduction
===================================

autolabor_simulation 提供了一套清晰的tf转换机制，尽管对于大多数用户来说tf转换是一个“黑箱”，
不了解这个部分并不影响用户愉快的使用模拟器，但理解ROS以及autolabor_simulation的tf转换机制能帮助
用户更好的控制他们的机器人，也使他们能够更快的查找出编码中可能的bug


TF Between Robot Base and Sensor Frame
==========================================

TODO
